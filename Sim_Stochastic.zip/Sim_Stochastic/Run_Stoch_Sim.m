clc; close all; clear all;
%  Stochastic Simulation of Hydrological/ Meteorological Variables using 6 Probability Distributions
%   by T. Benkaci & N. Dechemi 2020   
% 1 - Normal-2p Distribution         ---- Loi Normale            
% 2 - LogNormal-2p Distribution      ---- Loi Log Normale          
% 3 - Gumbel Distribution            ---- Loi Gumbel               
% 4 - Gen Ext-Va(GEV)Distribution    ---- Loi Gene-Extre-Va(GEV)   
% 5 - Gamma Distribution (Pearson3)  ---- Loi GAMMA             
% 6 - LogPearson-3p Distribution     ---- Loi LogPearson-3p         
     
%  Displays The different quantiles for the best Probability Fit. 

global P y m s n f 
%% Data Loaded
% Load Main File: with two columns
% Read Observed Data (Annual Rainfall(mm)), using Excel File.
PP = xlsread('File_Data.xlsx');
% You can use: Text file instead: PP = load('File_Data.txt').
D=PP(1:end,1:1); % The first Column is the Date (Years)
P=PP(1:end,2:2); % The Second Column is the Observed Data: Annual Precipitations in mm.


%% Statistical of Data used
% Caracteristics of Data, will be used in the Main program
% Caracteristiques Statistiques, seront utilisees dans le programme principal
Car_Stat=stat(P);
n=length(P);
m=mean(P); s=std(P);  % Mean and Standard Deviation
y=sort(P);
Cs=skewness(P); % Skewness of Data-  Coefficient d'Asymetrie


%% Plot Position Formula : We use 2 Formula:
% Probability Plot Position Formula---Frequence Empirique--Methode de HAZEN
j=1;% Plot Position: 1=Hazen method  - use 2= Weibull Formula Instead
    for i=1:n 
    if j==1
    f(i)=(i-0.5)/(n);
    else j==2
%Probability Plot Position Formula---Frequence Empirique--Methode de WEIBULL
    f(i)=i/(n+1);
    end
    end

%% Main File 
% The Main File Calculations (Protected File Pcode) call others Subroutines
% (Norm_Sim, LogN_Sim, Gumb_Sim ...)
Func_Sim